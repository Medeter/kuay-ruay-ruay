package com.mid.ruayruayruay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RuayruayruayApplicationTests {

	@Test
	void contextLoads() {
	}

}
